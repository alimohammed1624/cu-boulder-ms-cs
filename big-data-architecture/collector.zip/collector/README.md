# Tempest (Data Collector Micorservice)

## Instructions to run
To install dependencies
```
pip install -r requirements.txt
```
to run the server
```
gunicorn -b 0.0.0.0:8000 src.app:app
```

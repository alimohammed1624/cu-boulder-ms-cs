#!/usr/bin/env python3
import requests
from flask import Flask, jsonify, request
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from os import environ

app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///tempest.db"

"""
Define the database model
that is used to store 
the temperature.
"""

key = "e4418a5d189b4f9399e11616232809"

db = SQLAlchemy(app)


class Weather(db.Model):
    datetime = db.Column(db.DateTime, primary_key=True, default=datetime.utcnow())
    city = db.Column(db.String(80), nullable=False)
    temperature = db.Column(db.JSON, nullable=False)


@app.route("/")
def main():
    db.create_all()
    return """
    <h1>Tempest</h1>
    Enter a city to fetch temperature!
    <form action="/fetch" method="GET">
        <input name="city">
        <input type="submit" value="Fetch!">
    </form>
    <form action="/disp" method="GET">
        <input type="submit" value="Display all records!">
    </form>
    """


@app.route("/fetch", methods=["GET"])
def fetch():
    city = request.args.get("city", "")
    temperature = get_temperature(city)
    if temperature.get("error") is not None:
        return f"""
        Error: {temperature["error"]["message"]}
        <form action="/" method="GET">
            <input type="submit" value="Back to Home!">
        </form>
    """
    data = Weather(city=city, temperature=temperature)
    db.session.add(data)
    db.session.commit()
    return """
        Added to database!
        <form action="/disp" method="GET">
            <input type="submit" value="Display!">
        </form>
        <form action="/" method="GET">
            <input type="submit" value="Back to Home!">
        </form>
    """


@app.route("/disp", methods=["GET"])
def disp():
    data = Weather.query.all()
    return f"""
        {render_table(data)}
        <form action="/" method="GET">
            <input type="submit" value="Back to Home!">
        </form>
    """


"""
Helper function to get temperature
using API
"""


def render_table(data):
    table = "<table border = 1>"
    table += "<tr><th>City</th><th>Temperature</th><th>Time</th></tr>"
    for row in data:
        table += f"<tr><td>{row.city}</td><td>{row.temperature['current']['temp_c']}</td><td>{row.datetime}</td></tr>"
    table += "</table>"
    return table


def get_temperature(city):
    response = requests.get(
        f"http://api.weatherapi.com/v1/forecast.json?key={key}&q={city}&days=3"
    )
    return response.json()


"""
In main we first get the current temperature and then 
create a new object that we can add to the database. 
"""
with app.app_context():
    db.create_all()
